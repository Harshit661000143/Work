#ifndef sample_H
#define sample_H
int saxpy(int,float,float*,int,float*,int);
#endif


