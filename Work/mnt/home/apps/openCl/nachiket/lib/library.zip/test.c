#include<stdio.h>
#include"sample.h"
main(int argc,char** argv)
{
int i;
n=atoi(argv[1]);
alpha=atoi(argv[2]);
incx=atoi(argv[3]);
incy=atoi(argv[4]);
float *A = (float*)malloc(sizeof(float)*n);
float *B = (float*)malloc(sizeof(float)*n);
for(i=0;i<n;i++)
{
A[i]=1.0;
B[i]=1.0;
}
A=saxpy(n,alpha,A,incx,B,incy);
return 0;
}
