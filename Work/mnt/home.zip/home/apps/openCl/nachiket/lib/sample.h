#ifndef sample_H
#define sample_H
float *saxpy(int,float,float*,int,float*,int);
float *scalar(int, float, float*,int );
float dot(int, float*,int,float*,int);
#endif


