#!/usr/bin/perl
open($files,"$ARGV[0]") or die("Can't locate file $ARGV[0]\n");
$flag = 0;
$mark = 0;
$count = 0;
$precdt1=0;
$precdt2=0;
$adt=0;
$max1=0;
$max2=0;
$max3=0;

open(NEWDAT,">Data_File") or die("Can  not locate file Data File\n");
while($entry=<$files>)
{
	chomp($entry);
        if($entry=~/\:/)
{
	@items=split(/\:/,$entry); 
        $matrix=$items[0];
        @items1=split(/=/,$entry);
        $ttime=$items1[1];
#        print NEWDAT "$matrix\t$ttime\n";

        print "$matrix\t$ttime\n";
}
}
