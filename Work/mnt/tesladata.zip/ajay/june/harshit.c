#include <stdio.h>
#include <stdlib.h>
#include <CL/cl.h>
void dump_error(cl_int *err)
{

if(err[0]==CL_INVALID_PLATFORM)
{

printf("\nInvalid platform");
}

else if (err[0]==CL_INVALID_DEVICE)
{
printf("\nInvalid Device");
}

else if(err[0]==CL_INVALID_CONTEXT)
{
printf("\nInvalid Context");
}

else if(err[0]==CL_INVALID_KERNEL)
{
printf("\nInvalid kernel");
}

else if(err[0]==CL_INVALID_VALUE)
{
printf("\nInvalid value");
}

else if(err[0]==CL_INVALID_QUEUE_PROPERTIES)
{
printf("\nInvalid properties");
}

else if(err[0]==CL_OUT_OF_HOST_MEMORY)
{
printf("\nOut of host memory");
}

else if(err[0]==CL_INVALID_KERNEL)
{
printf("\nError in kernel launch");
}

}

int main(void) {
    // Create the two input vectors
    int i,n,m,j;
   
   printf("enter the no. of rows");
scanf("%d",&m);  


n=m*m;
    int *A = (int*)malloc(sizeof(int)*n);
    int *B = (int*)malloc(sizeof(int)*n);
    
    for(i = 0; i < n; i++) 
{
        A[i] = i;
        B[i] = n-i;
    }

 // Load the kernel source code into the array source_str
  const char *source ="__kernel void matrix_add(__global int *A, __global int *B, __global int *C) {int tx = get_global_id(0);int ty = get_global_id(1);float value = 0;for (int k = 0; k < m; ++k){float elementA = A[ty * m + k];float elementB = B[k * m + tx];value += elementA * elementB;}C[ty * m + tx] = value;}";

    // Get platform and device information
    cl_platform_id platform_id = NULL;
    cl_device_id device_id = NULL;   
    cl_uint ret_num_devices;
    cl_uint ret_num_platforms;
    cl_int ret = clGetPlatformIDs(1, &platform_id, &ret_num_platforms);
if(ret!=CL_SUCCESS)
{
printf("platform id error");
}
dump_error(&ret);
    ret = clGetDeviceIDs( platform_id, CL_DEVICE_TYPE_GPU, 1, &device_id, &ret_num_devices);
dump_error(&ret);

    // Create an OpenCL context
    cl_context context = clCreateContext( NULL, 1, &device_id, NULL, NULL, &ret);

    // Create a command queue
   cl_command_queue command_queue = clCreateCommandQueue( context,device_id,0, NULL );

    // Create memory buffers on the device for each vector 
    cl_mem a_mem_obj = clCreateBuffer(context, CL_MEM_READ_ONLY,n * sizeof(int), NULL, &ret);
    cl_mem b_mem_obj = clCreateBuffer(context, CL_MEM_READ_ONLY, n * sizeof(int), NULL, &ret);
    cl_mem c_mem_obj = clCreateBuffer(context, CL_MEM_WRITE_ONLY, n * sizeof(int), NULL, &ret);

    // Copy the lists A and B to their respective memory buffers
    ret = clEnqueueWriteBuffer(command_queue, a_mem_obj, CL_TRUE, 0,n * sizeof(int), A, 0, NULL, NULL);
dump_error(&ret);

    ret = clEnqueueWriteBuffer(command_queue, b_mem_obj, CL_TRUE, 0,n * sizeof(int), B, 0, NULL, NULL);
dump_error(&ret);

    // Create a program from the kernel source
   
cl_program program = clCreateProgramWithSource( context,1,&source,NULL, NULL );

    // Build the program
    ret = clBuildProgram(program, 1, &device_id, NULL, NULL, NULL);
dump_error(&ret);


    // Create the OpenCL kernel
    cl_kernel kernel = clCreateKernel(program, "matrix_add", &ret);

    // Set the arguments of the kernel
    ret = clSetKernelArg(kernel, 0, sizeof(cl_mem), (void *)&a_mem_obj);
dump_error(&ret);

    ret = clSetKernelArg(kernel, 1, sizeof(cl_mem), (void *)&b_mem_obj);
dump_error(&ret);

    ret = clSetKernelArg(kernel, 2, sizeof(cl_mem), (void *)&c_mem_obj);
dump_error(&ret);
    
    // Execute the OpenCL kernel on the list
    size_t localWorkSize[2], globalWorkSize[2]; // Process the entire lists
localWorkSize[0] =m ;
   localWorkSize[1] = m;
   globalWorkSize[0] = m;
   globalWorkSize[1] = m;
 

   
 ret = clEnqueueNDRangeKernel(command_queue, kernel, 2, NULL,globalWorkSize,localWorkSize, 0, NULL, NULL);
dump_error(&ret);



    // Read the memory buffer C on the device to the local variable C
    int *C = (int*)malloc(sizeof(int)*n);
    ret = clEnqueueReadBuffer(command_queue, c_mem_obj, CL_TRUE, 0, n * sizeof(int), C, 0, NULL, NULL);
dump_error(&ret);

    // Display the result to the screen

 printf("A=\t");  
  for(i = 0; i < m; i++)
{
printf("\n");
for(j=0;j<m;j++)
{
printf("%d\t",A[i*m+j]);
}}

printf("\nB=\t");  
  for(i = 0; i < m; i++)
{
printf("\n");
for(j=0;j<m;j++)
{
printf("%d\t",B[i*m+j]);
}}

printf("\nC=\t");  
  for(i = 0; i < m; i++)
{
printf("\n");
for(j=0;j<m;j++)
{
printf("%d\t",C[i*m+j]);
}}
printf("\n");
 
    return 0;
}

