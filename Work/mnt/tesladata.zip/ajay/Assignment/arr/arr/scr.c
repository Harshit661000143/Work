#include<stdio.h>
#include<stdlib.h>
#include<CL/cl.h>
main()
{printf("enter the size of list");
int i,n,j;
j=1;
scanf("%d",&n);
int *A=(int*)malloc(sizeof(int)*n);
int *max=(int*)malloc(sizeof(int)*j);
cl_platform_id platform;
srand(100);
for( i=0;i<n;i++)
{
A[i]=rand()%10;
}
cl_device_id device;
cl_int error;
error=clGetPlatformIDs(1,&platform,NULL);
error=clGetDeviceIDs(platform,CL_DEVICE_TYPE_GPU,1,&device,NULL);
cl_context context=clCreateContext(NULL,1,&device,NULL,NULL,&error);
cl_command_queue queue= clCreateCommandQueue(context,device,0,&error);
cl_mem aM=clCreateBuffer(context,CL_MEM_READ_WRITE,n*sizeof(int),NULL,&error);
 error = clEnqueueWriteBuffer(queue, aM, CL_TRUE, 0,n * sizeof(int), A, 0, NULL, NULL);
cl_mem max_mem_obj = clCreateBuffer(context, CL_MEM_WRITE_ONLY, j * sizeof(int), NULL, &error);
 
 FILE *fp;
    char *source_str;
    int source_size;

    fp = fopen("max.cl", "r");
    if (!fp) {
        printf("Failed to load kernel.\n");
        exit(1);
    }

  source_str = (char*)malloc(100000);
    source_size = fread( source_str, 1, 100000, fp);
    fclose( fp );
 cl_program program = clCreateProgramWithSource(context, 1, (const char **)&source_str,(const size_t *)&source_size, &error);
error = clBuildProgram(program, 1, &device, NULL, NULL, NULL);
cl_kernel kernel = clCreateKernel(program, "max", &error);
error=clSetKernelArg(kernel, 0, sizeof(cl_mem), (void *)&aM);
 size_t global_item_size = n; // Process the entire lists
  size_t local_item_size = n/2;//  Process one item at a time

  error = clEnqueueNDRangeKernel(queue, kernel, 1, NULL,&global_item_size, &local_item_size, 0, NULL, NULL);
error = clEnqueueReadBuffer(queue, max_mem_obj, CL_TRUE, 0,1 * sizeof(int), max, 0, NULL, NULL);
error = clEnqueueReadBuffer(queue, aM, CL_TRUE, 0,n * sizeof(int), A, 0, NULL, NULL);
for(i=0;i<n;i++)
{printf("\n%d",A[i]);}
printf("\nmax is %d",max[0]);
}
