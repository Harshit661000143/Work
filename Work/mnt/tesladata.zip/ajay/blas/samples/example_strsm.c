/***********************************************************************
**  Copyright (C) 2010,2011 Advanced Micro Devices, Inc. All Rights Reserved.
***********************************************************************/

#include <sys/types.h>
#include <stdio.h>
#include <string.h>

/* Include CLBLAS header. It automatically includes needed OpenCL header,
 * so we can drop out explicit inclusion of cl.h header.
 */
#include <clAmdBlas.h>

/* This example uses predefined matrices and their characteristics for
 * simplicity purpose.
 */
static const clAmdBlasOrder order = clAmdBlasRowMajor;
static const clAmdBlasSide side = clAmdBlasLeft;

static const size_t M = 4;
static const size_t N = 5;

static const cl_float alpha = 10;

static const clAmdBlasTranspose transA = clAmdBlasNoTrans;
static const clAmdBlasUplo uploA = clAmdBlasUpper;
static const clAmdBlasDiag diagA = clAmdBlasNonUnit;
static const cl_float A[] = {
    11, 12, 13, 14,
     0, 22, 23, 24,
     0,  0, 33, 34,
     0,  0,  0, 44
};
static const size_t lda = 4;    /* i.e. lda = M */

static cl_float B[] = {
    11, 12, 13, 14, 15,
    21, 22, 23, 24, 25,
    31, 32, 33, 34, 35,
    41, 42, 43, 44, 45
};
static const size_t ldb = 5;    /* i.e. ldb = N */

static void
printResult(void)
{
    size_t i, j, nrows;

    printf("Result:\n");

    nrows = (sizeof(B) / sizeof(cl_float)) / ldb;
    for (i = 0; i < nrows; i++) {
        for (j = 0; j < ldb; j++) {
            printf("%.5e ", B[i * ldb + j]);
        }
        printf("\n");
    }
}

int
main(int argc, const char *argv[])
{
    cl_int err;
    cl_platform_id platform;
    cl_device_id device;
    cl_context_properties props[3] = { CL_CONTEXT_PLATFORM, 0, 0 };
    cl_context ctx;
    cl_command_queue queue;
    cl_mem bufA, bufB;
    cl_event event = NULL;
    cl_ulong img = 0;
    int useImages = 0;
    int ret = 0;

    /* parse the command line */
    if ((argc > 1) && !strcmp(argv[1], "--use-images")) {
        useImages = 1;
    }

    /* Setup OpenCL environment. */
    err = clGetPlatformIDs(1, &platform, NULL);
    err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, 1, &device, NULL);
    props[1] = (cl_context_properties)platform;
    ctx = clCreateContext(props, 1, &device, NULL, NULL, &err);
    queue = clCreateCommandQueue(ctx, device, 0, &err);

    /* Setup clAmdBlas. */
    err = clAmdBlasSetup();
    if (err != CL_SUCCESS) {
        printf("clAmdBlasSetup() failed with %d\n", err);
        clReleaseCommandQueue(queue);
        clReleaseContext(ctx);
        return 1;
    }

    /* Prepare OpenCL memory objects and place matrices inside them. */
    bufA = clCreateBuffer(ctx, CL_MEM_READ_ONLY, M * M * sizeof(*A),
                          NULL, &err);
    bufB = clCreateBuffer(ctx, CL_MEM_READ_WRITE, M * N * sizeof(*B),
                          NULL, &err);

    err = clEnqueueWriteBuffer(queue, bufA, CL_TRUE, 0,
        M * M * sizeof(*A), A, 0, NULL, NULL);
    err = clEnqueueWriteBuffer(queue, bufB, CL_TRUE, 0,
        M * N * sizeof(*B), B, 0, NULL, NULL);

    if (useImages) {
        /* add a scratch image to evaluate with an image based kernel */ 
        img = clAmdBlasAddScratchImage(ctx, 16, 64, NULL);
    } 

    /* Call clAmdBlas function. */
    err = clAmdBlasStrsm(order, side, uploA, transA, diagA, M, N,
                         alpha, bufA, lda, bufB, ldb, 1, &queue, 0,
                         NULL, &event);
    if (err != CL_SUCCESS) {
        printf("clAmdBlasStrsm() failed with %d\n", err);
        ret = 1;
    }
    else {
        /* Wait for calculations to be finished. */
        err = clWaitForEvents(1, &event);

        /* Fetch results of calculations from GPU memory. */
        err = clEnqueueReadBuffer(queue, bufB, CL_TRUE, 0, M * N * sizeof(*B),
                                  B, 0, NULL, NULL);
    
        /* At this point you will get the result of STRSM placed in B array. */
        printResult();
    }

    /* Remove the scratch OpenCL image */
    if (useImages) {
        clAmdBlasRemoveScratchImage(img);
    }

    /* Release OpenCL memory objects. */
    clReleaseMemObject(bufB);
    clReleaseMemObject(bufA);

    /* Finalize work with clAmdBlas. */
    clAmdBlasTeardown();

    /* Release OpenCL working objects. */
    clReleaseCommandQueue(queue);
    clReleaseContext(ctx);

    return ret;
}
