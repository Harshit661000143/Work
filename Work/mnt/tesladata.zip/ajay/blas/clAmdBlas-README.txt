clAmdBlas Readme
*****************************
*****************************

clAmdBlas Known Issues:
*****************************
1)  It is recommended that windows users uninstall previous versions of clAmdBlas
    before installing newer versions.  Otherwise, Add/Remove programs only
    removes the latest version.  Linux users can delete the install
    directory.
	
2)  The clAmdBlasTune executable has been observed to hang in a few configurations
    on Windows.  If this happens, simply abort execution of the tune program; it is
    not required for correct operation of the BLAS routines.

ChangeLog:
*****************************

Version 1.2 release:
*****************************
-New)  The library now supports both 32- and 64-bit Windows and Linux operating 
       systems.

-New)  xTRSM routines are available in 1.2.
-----------------------------
-Fix)  xTRMM routines were not properly handling implicit unit diagonal 
       elements and implicit off-diagonal zero values specified by the BLAS 
       parameters SIDE, UPLO and DIAG.

-Fix)  Possible crash with CPU device on 32-bit systems.

-Fix)  clAmdBlasDgemm routine return an invalid event as its last argument.

-Fix)  clAmdBlas routines return clAmdBlasStatus error codes, instead of 
       native OpenCL error codes.

Windows (R):
*****************************
clAmdBlas is built linking dynamically to the Visual Studio 2010 runtime library.  
If the user tries to run the included software on a machine that does not have the 
appropriate runtime installed, an error message dialog box appears, informing 
the user that the program cannot run.  In this case, Microsoft (R) provides the 
C runtime as a free download that can be installed to resolve that dependency.

Microsoft Visual C++ (R) 2010 Redistributable Package (x86)
-------------------------------------------------------
http://www.microsoft.com/downloads/en/details.aspx?familyid=A7B7A05E-6DE6-4D3A-A423-37BF0912DB84

Microsoft Visual C++ 2010 Redistributable Package (x64)
-------------------------------------------------------
http://www.microsoft.com/downloads/en/details.aspx?FamilyID=bd512d9e-43c8-4655-81bf-9350143d5867


To install the Windows versions of clAmdBlas, simply double-click the installer 
file, and choose the installation directory.

The sample program does not ship with native build files; instead, a CMake file is 
shipped and users generate a native build file for their system.

For example:

	Execute CMake-gui program.

	Fill out the source and binary generation text fields.
	- Source code location: ${installDir}\samples
	- Where to build the binaries: ${installDir}\samplesBin

	Click on Configure.
	- Cmake prompts the user to choose the kind of build files to generate; 
          typical choices are 'Visual Studio' solutions and NMake makefiles.  
	--- If errors are reported for NMake projects during configuration, it may 
            be necessary to launch CMake-gui from a visual studio command line 
            prompt.
	- Ensure that the dependencies to external libraries are satisfied; this 
          includes paths to 'ATI Stream SDK'.
	- After dependencies are satisfied, click on Configure again to finalize 
          the configure step.

	Click on Generate to generate the build files that were chosen in the 
        previous step.

	If Visual Studio files where generated, open the Solution .sln file in the 
        appropriate editor.

	If NMake files were generated, open a Visual studio command-line prompt to 
        have the appropriate environment set for compilation.


Linux:
*****************************
To install the Linux versions of clAmdBlas, uncompress the initial download, then 
execute the install script.

For example:

	tar -xf clAmdBlas-${version}-Linux.tar.gz
		- This installs three files into the local directory, one being an 
                  executable bash script.

	sudo mkdir /opt/clAmdBlas-${version}
		- This pre-creates the install directory with proper permissions 
                  in /opt if it is to be installed there. (This is the default.)

	./install-clAmdBlas-${version}.sh
                - This prints an EULA and uncompresses files into the chosen 
                  install directory.

	cd ${installDir}/bin64
	export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${OpenCLLibDir}:${clAmdBlasLibDir}
		- Be sure to export library dependencies to resolve all external 
                  linkages to the client program; you can create a bash script to 
                  help automate this procedure.

	./example_sgemm
		- Run a simple client; one example is provided for each supported 
                  main BLAS function family.

The sample program does not ship with native build files; instead, a CMake file is 
shipped, and the user generates a native build file for their system.

For example:

	cd ${installDir}

	mkdir samplesBin/
		- This creates a sister directory to the samples directory that 
                  houses the native makefiles and the generated files from the 
                  build.

	cd samplesBin/
	ccmake ../samples/
		- ccmake is a curses-based cmake program; it takes a parameter 
                  that specifies the location of the source code to compile.
		- Hit 'c' to configure for the platform; ensure that the 
                  dependencies to external libraries are satisfied, including 
                  paths to 'ATI Stream SDK'.
		- After dependencies are satisfied, hit 'c' again to finalize 
                  configuration. Then, hit 'g' to generate a makefile and 
                  exit ccmake.

	make help
		- Look at the options available for make.

	make
		- Build the sample client program.

	./example_sgemm
		- Run a simple client; one example is provided for each supported main BLAS function family.
___________________________________________________
(C) 2010,2011 Advanced Micro Devices, Inc. All rights reserved. AMD, the AMD Arrow logo, ATI, the ATI logo, Radeon, FireStream, FireGL, Catalyst, and combinations thereof are trademarks of Advanced Micro Devices, Inc. Microsoft (R), Windows, and Windows Vista (R) are registered trademarks of Microsoft Corporation in the U.S. and/or other jurisdictions. OpenCL and the OpenCL logo are trademarks of Apple Inc. used by permission by Khronos. Other names are for informational purposes only and may be trademarks of their respective owners.

The contents of this document are provided in connection with Advanced Micro Devices, Inc. ("AMD") products. AMD makes no representations or warranties with respect to the accuracy or completeness of the contents of this publication and reserves the right to make changes to specifications and product descriptions at any time without notice. The information contained herein may be of a preliminary or advance nature and is subject to change without notice. No license, whether express, implied, arising by estoppel or otherwise, to any intellectual property rights is granted by this publication. Except as set forth in AMD's Standard Terms and Conditions of Sale, AMD assumes no liability whatsoever, and disclaims any express or implied warranty, relating to its products including, but not limited to, the implied warranty of merchantability, fitness for a particular purpose, or infringement of any intellectual property right.

AMD's products are not designed, intended, authorized or warranted for use as components in systems intended for surgical implant into the body, or in other applications intended to support or sustain life, or in any other application in which the failure of AMD's product could create a situation where personal injury, death, or severe property or environmental damage may occur. AMD reserves the right to discontinue or make changes to its products at any time without notice.
___________________________________________________

