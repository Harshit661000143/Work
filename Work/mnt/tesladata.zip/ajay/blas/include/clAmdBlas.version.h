/***********************************************************************
** Copyright (C) 2010,2011 Advanced Micro Devices, Inc. All Rights Reserved.
***********************************************************************/

/* the configured version and settings for clAmdBlas
 */
#define clAmdBlasVersionMajor 1
#define clAmdBlasVersionMinor 2
#define clAmdBlasVersionPatch 144
