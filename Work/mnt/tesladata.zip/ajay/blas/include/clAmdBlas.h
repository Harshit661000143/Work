/***********************************************************************
** Copyright (C) 2010,2011 Advanced Micro Devices, Inc. All Rights Reserved.
***********************************************************************/

#ifndef CLAMDBLAS_H_
#define CLAMDBLAS_H_

/**
 * @mainpage OpenCL BLAS-3
 *
 * This is an implementation of
 * <A HREF="http://en.wikipedia.org/wiki/Basic_Linear_Algebra_Subprograms">
 * Basic Linear Algebra Subprograms</A>, level 3 (BLAS-3) using
 * <A HREF="http://www.khronos.org/opencl/">OpenCL</A> and optimized for
 * the AMD GPU hardware.
 */

#if defined(__APPLE__) || defined(__MACOSX)
#include <OpenCL/cl.h>
#else
#include <CL/cl.h>
#endif

#include <clAmdBlas-complex.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup Overview
 *
 * The library provides implementation of BLAS-3 subprograms subset
 * including such families as xGEMM, xTRMM and xTRSM. Each function family
 * supports 4 data types: float, double, complex float and complex double.
 * The primary library's goals is to select a good strategy for problem
 * evaluation, select a fast OpenCL kernel and enqueue it. It offers an OpenCL
 * friendly API that means that a user is fully responsible for command queues,
 * events and memory objects creation, and waiting on events. Currently all the
 * functions accept matrices through memory objects. OpenCL kernels using such
 * objects are relatively slow, and for getting better performance the library
 * allows to create scratch images so that to leverage image based kernels which
 * provide in upto 2-3 times better performance. In order to get the best
 * performance with memory objects it's recommended to use matrices with sizes
 * aligned on the bound of 64.
 */

/**
 * @defgroup enums Options
 */
/*@{*/

/** Shows how matrices are placed in memory */
typedef enum clAmdBlasOrder {
    clAmdBlasRowMajor,           /**< Every row is placed sequentially */
    clAmdBlasColumnMajor         /**< Every column is placed sequentially */
} clAmdBlasOrder;

/** It is used to specify whether the matrix should be transposed or not. */
typedef enum clAmdBlasTranspose {
    clAmdBlasNoTrans,           /**< Operate with the matrix. */
    clAmdBlasTrans,             /**< Operate with the transpose of the matrix. */
    clAmdBlasConjTrans          /**< Operate with the conjugate transpose of
                                     the matrix. */
} clAmdBlasTranspose;

/** It is used by the Hermitian, symmetric and triangular matrix
 * routines to specify whether the upper or lower triangle is being referenced.
 */
typedef enum clAmdBlasUplo {
    clAmdBlasUpper,               /**< Upper triangle. */
    clAmdBlasLower                /**< Lower triangle. */
} clAmdBlasUplo;

/** It is used by the triangular matrix routines to specify whether the
 * matrix is unit triangular.
 */
typedef enum clAmdBlasDiag {
    clAmdBlasUnit,               /**< Unit triangular. */
    clAmdBlasNonUnit             /**< Non-unit triangular. */
} clAmdBlasDiag;

/** The side matrix A is located at against matrix B */
typedef enum clAmdBlasSide {
    clAmdBlasLeft,        /**< Multiply general matrix by symmetric,
                               Hermitian or triangular matrix on the left. */
    clAmdBlasRight        /**< Multiply general matrix by symmetric,
                               Hermitian or triangular matrix on the right. */
} clAmdBlasSide;

/**
 *   @brief clAmdBlas error codes definition, incorporating OpenCL error
 *   definitions
 *
 *   This enumeration is a subset of the OpenCL error codes extended with some
 *   additional extra codes.  For example, CL_OUT_OF_HOST_MEMORY, which is
 *   defined in cl.h is aliased as clAmdBlasOutOfHostMemory.
 */
typedef enum clAmdBlasStatus {
    clAmdBlasSuccess                         = CL_SUCCESS,
    clAmdBlasInvalidValue                    = CL_INVALID_VALUE,
    clAmdBlasInvalidCommandQueue             = CL_INVALID_COMMAND_QUEUE,
    clAmdBlasInvalidContext                  = CL_INVALID_CONTEXT,
    clAmdBlasInvalidMemObject                = CL_INVALID_MEM_OBJECT,
    clAmdBlasInvalidDevice                   = CL_INVALID_DEVICE,
    clAmdBlasOutOfResources                  = CL_OUT_OF_RESOURCES,
    clAmdBlasOutOfHostMemory                 = CL_OUT_OF_HOST_MEMORY,
    clAmdBlasInvalidOperation                = CL_INVALID_OPERATION,
    clAmdBlasCompilerNotAvailable            = CL_COMPILER_NOT_AVAILABLE,
    clAmdBlasBuildProgramFailure             = CL_BUILD_PROGRAM_FAILURE,
    /* Extended error codes */
    /* Functionality is not implemented */
    clAmdBlasNotImplemented                  = -1024
} clAmdBlasStatus;


/*@}*/

/**
 * @defgroup VERSIONING Version information
 */
/*@{*/

/**
 * @brief Get the clAmdBlas library version info
 *
 * @param[out] major        Location to store library's major version
 * @param[out] minor        Location to store library's minor version
 * @param[out] patch        Location to store library's patch version
 *
 * @returns always \b clAmdBlasSuccess
 */
clAmdBlasStatus
clAmdBlasGetVersion(cl_uint* major, cl_uint* minor, cl_uint* patch);

/*@}*/

/**
 * @defgroup INIT Initialization/deinitialization
 */
/*@{*/

/**
 * @brief Initialize the clAmdBlas library.
 *
 * Function initializes the clAmdBlas library and must be called before any other
 * clAmdBlas API function is invoked.
 *
 * @return \b clAmdBlasSucces on success, the following error codes otherwise:
 *   - \b clAmdBlasOutOfHostMemory if there is not enough of memory to allocate
 *     library's internal structures
 *   - \b clAmdBlasOutOfResources in case of requested resources scarcity
 */
clAmdBlasStatus
clAmdBlasSetup(void);

/**
 * @brief Finalize the usage of the clAmdBlas library.
 *
 * Function frees all memory allocated for different computational kernel and
 * other internal data.
 */
void
clAmdBlasTeardown(void);

/*@}*/

/**
 * @defgroup MISC Miscellaneous
 */
/*@{*/

/**
 * @brief Create scratch image.
 *
 * Images created with this function can be used by the library to switch
 * from a buffer based implementation to an image based implementation.
 * Its advantage is that it can run in upto 2-3 times faster than the buffer
 * based one. To leverage this one of GEMM and TRMM kernels it is needed to
 * create 2 images. For GEMM, image width should be sufficient to fit K elements
 * in every row. For TRMM with matrix A placed on the left, image's rows should
 * have width enough to fit M and N elements respectively. For TRMM with
 * matrix A placed on the right, both the images should have width enough to fit
 * N elements in every row. Eventually, to guarantee using of the images its
 * width should be aligned on the bound of 64 respective elements. Image height
 * can be much lesser then matrix height, but not lesser than 64. In this case
 * a problem is evaluated in parts. For a TRSM case only one image is needed,
 * its size should be sufficient to fit all effective data in matrix A with
 * 32x32 blocks.
 *
 * @return non zero identifier of created image on success; on error returns
 *         0 and puts an error code in the 'error' location.
 */
cl_ulong
clAmdBlasAddScratchImage(
    cl_context context,
    size_t width,
    size_t height,
    clAmdBlasStatus *status);

/**
 * @brief Release scratch image.
 *
 * @return \b clAmdBlasSuccess on success, \b clAmdBlasInvalidValue if an
 * invalid image identified is passed
 */
clAmdBlasStatus
clAmdBlasRemoveScratchImage(
    cl_ulong imageID);

/*@}*/

/**
 * @defgroup GEMM xGEMM - General matrix-matrix multiplication
 */
/*@{*/

/**
 * @brief Matrix-matrix product of general rectangular matrices with float
 * elements.
 *
 * Matrix-matrix products:
 *   - \f$ C \leftarrow \alpha A B + \beta C \f$
 *   - \f$ C \leftarrow \alpha A^T B + \beta C \f$
 *   - \f$ C \leftarrow \alpha A B^T + \beta C \f$
 *   - \f$ C \leftarrow \alpha A^T B^T + \beta C \f$
 *
 * @param[in] order     Row/column order.
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] transB    How matrix \b B should be transposed.
 * @param[in] M         Number of rows in matrix \b A.
 * @param[in] N         Number of columns in matrix \b B.
 * @param[in] K         Number of columns in matrix \b A and rows in matrix \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. It should be not less
 *                      than \b K when the \b order parameter is set to
 *                      \b clAmdBlasRowMajor,\n or not less than \b M when the
 *                      parameter is set to \b clAmdBlasColumnMajor.
 * @param[in] B         Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. It should be not less
 *                      than \b N when the \b order parameter is set to
 *                      \b clAmdBlasRowMajor,\n or not less than \b K
 *                      when it is set to \b clAmdBlasColumnMajor.
 * @param[in] beta      The factor of matrix \b C.
 * @param[out] C        Matrix \b C itself.
 * @param[in] ldc       Leading dimension of matrix \b C. It should be not less
 *                      than \b N when the \b order parameter is set to
 *                      \b clAmdBlasRowMajor,\n or not less than \b M when
 *                      it is set to \b clAmdBlasColumnMajorOrder.
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return \b clAmdBlasSuccess on success; following error codes otherwise:
 *   - \b clAmdBlasInvalidValue if invalid parameters are passed:
 *     \b M, \b N or \b K is zero, or a leading dimension is invalid, or the
 *     \b numCommandQueues parameter is not equal to 1
 *   - \b clAmdBlasInvalidMemObject if A, B, or C object is invalid,
 *     or an image object rather than the buffer one;
 *   - \b clAmdBlasOutOfHostMemory if the library can't allocate memory for
 *     internal structures
 *   - \b clAmdBlasInvalidCommandQueue if the passed command queue is invalid
 *   - \b clAmdBlasInvalidContext if a context a passed command queue belongs to
 *     was released
 *   - \b clAmdBlasInvalidOperation if kernel compilation relating to a previous
 *     call has not completed for any of the target devices
 *   - \b clAmdBlasCompilerNotAvailable if a compiler is not available
 *   - \b clAmdBlasBuildProgramFailure if there is a failure to build a program
 *     executable
 * @ingroup GEMM
 */
clAmdBlasStatus
clAmdBlasSgemm(
    clAmdBlasOrder order,
    clAmdBlasTranspose transA,
    clAmdBlasTranspose transB,
    size_t M,
    size_t N,
    size_t K,
    cl_float alpha,
    const cl_mem A,
    size_t lda,
    const cl_mem B,
    size_t ldb,
    cl_float beta,
    cl_mem C,
    size_t ldc,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/**
 * @example example_sgemm.c
 * This is an example of how to use the @ref clAmdBlasSgemm function.
 */

/**
 * @brief Matrix-matrix product of general rectangular matrices with double
 * elements.
 *
 * Matrix-matrix products:
 *   - \f$ C \leftarrow \alpha A B + \beta C \f$
 *   - \f$ C \leftarrow \alpha A^T B + \beta C \f$
 *   - \f$ C \leftarrow \alpha A B^T + \beta C \f$
 *   - \f$ C \leftarrow \alpha A^T B^T + \beta C \f$
 *
 * @param[in] order
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] transB    How matrix \b B should be transposed.
 * @param[in] M         Number of rows in matrix \b A.
 * @param[in] N         Number of columns in matrix \b B.
 * @param[in] K         Number of columns in matrix \b A and rows in matrix \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object soring matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. For detailed description
 *                      see clAmdBlasSgemm().
 * @param[in] B         Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. For detailed description
 *                      see clAmdBlasSgemm().
 * @param[in] beta      The factor of matrix \b C.
 * @param[out] C        Buffer object storing matrix \b C.
 * @param[in] ldc       Leading dimension of matrix \b C. For detailed description
 *                      see clAmdBlasSgemm().
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return \b clAmdBlasSuccess on success; \b clAmdBlasInvalidDevice if a target
 *         device does not support floating point arithmetic with double
 *         precision; the same error codes as the clAmdBlasSgemm() function
 *         otherwise.
 * @ingroup GEMM
 */
clAmdBlasStatus
clAmdBlasDgemm(
    clAmdBlasOrder order,
    clAmdBlasTranspose transA,
    clAmdBlasTranspose transB,
    size_t M,
    size_t N,
    size_t K,
    cl_double alpha,
    const cl_mem A,
    size_t lda,
    const cl_mem B,
    size_t ldb,
    cl_double beta,
    cl_mem C,
    size_t ldc,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/**
 * @brief Matrix-matrix product of general rectangular matrices with float
 * complex elements.
 *
 * Matrix-matrix products:
 *   - \f$ C \leftarrow \alpha A B + \beta C \f$
 *   - \f$ C \leftarrow \alpha A^T B + \beta C \f$
 *   - \f$ C \leftarrow \alpha A B^T + \beta C \f$
 *   - \f$ C \leftarrow \alpha A^T B^T + \beta C \f$
 *
 * @param[in] order
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] transB    How matrix \b B should be transposed.
 * @param[in] M         Number of rows in matrix \b A.
 * @param[in] N         Number of columns in matrix \b B.
 * @param[in] K         Number of columns in matrix \b A and rows in matrix \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. For detailed
 *                      description see clAmdBlasSgemm().
 * @param[in] B         Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. For detailed
 *                      description see clAmdBlasSgemm().
 * @param[in] beta      The factor of matrix \b C.
 * @param[out] C        Buffer object storing matrix \b C.
 * @param[in] ldc       Leading dimension of matrix \b C. For detailed
 *                      description see clAmdBlasSgemm().
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return The same result as the clAmdBlasSgemm() function.
 * @ingroup GEMM
 */
clAmdBlasStatus
clAmdBlasCgemm(
    clAmdBlasOrder order,
    clAmdBlasTranspose transA,
    clAmdBlasTranspose transB,
    size_t M,
    size_t N,
    size_t K,
    FloatComplex alpha,
    const cl_mem A,
    size_t lda,
    const cl_mem B,
    size_t ldb,
    FloatComplex beta,
    cl_mem C,
    size_t ldc,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/**
 * @brief Matrix-matrix product of general rectangular matrices with double
 * complex elements.
 *
 * Matrix-matrix products:
 *   - \f$ C \leftarrow \alpha A B + \beta C \f$
 *   - \f$ C \leftarrow \alpha A^T B + \beta C \f$
 *   - \f$ C \leftarrow \alpha A B^T + \beta C \f$
 *   - \f$ C \leftarrow \alpha A^T B^T + \beta C \f$
 *
 * @param[in] order
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] transB    How matrix \b B should be transposed.
 * @param[in] M         Number of rows in matrix \b A.
 * @param[in] N         Number of columns in matrix \b B.
 * @param[in] K         Number of columns in matrix \b A and rows in matrix \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. For detailed
 *                      description see clAmdBlasSgemm().
 * @param[in] B         Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. For detailed
 *                      description see clAmdBlasSgemm().
 * @param[in] beta      The factor of matrix \b C.
 * @param[out] C        Buffer object storing matrix \b C.
 * @param[in] ldc       Leading dimension of matrix \b C. For detailed
 *                      description see clAmdBlasSgemm().
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return The same result as the clAmdBlasDgemm() function.
 * @ingroup GEMM
 */
clAmdBlasStatus
clAmdBlasZgemm(
    clAmdBlasOrder order,
    clAmdBlasTranspose transA,
    clAmdBlasTranspose transB,
    size_t M,
    size_t N,
    size_t K,
    DoubleComplex alpha,
    const cl_mem A,
    size_t lda,
    const cl_mem B,
    size_t ldb,
    DoubleComplex beta,
    cl_mem C,
    size_t ldc,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/*@}*/

/**
 * @defgroup TRMM xTRMM - Matrix-triangular matrix multiplication
 */
/*@{*/

/**
 * @brief Multiplying a matrix by a triangular matrix with float elements.
 *
 * Matrix-triangular matrix products:
 *   - \f$ B \leftarrow \alpha T B \f$
 *   - \f$ B \leftarrow \alpha T^T B \f$
 *   - \f$ B \leftarrow \alpha B T \f$
 *   - \f$ B \leftarrow \alpha B T^T \f$
 *
 * where \b T is an upper or lower triangular matrix.
 *
 * @param[in] order
 * @param[in] side      The side of triangular matrix.
 * @param[in] uplo      The triangle in matrix being referenced.
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] diag      Specify whether matrix is unit triangular.
 * @param[in] M         Number of rows in matrices \b A and \b B.
 * @param[in] N         Number of columns in matrices \b A and \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. It should be not less
 *                      than \b M when the \b side parameter is set to
 *                      \b clAmdBlasLeft,\n or not less than \b N when it is set
 *                      to \b clAmdBlasRight.
 * @param[out] B        Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. It should be not less
 *                      than \b N when the \b order parameter is set to
 *                      \b clAmdBlasRowMajor,\n or not less than \b M
 *                      when it is set to \b clAmdBlasColumnMajor.
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return \b clAmdBlasSuccess on success; following error codes otherwise:
 *   - \b clAmdBlasInvalidValue if invalid parameters are passed:
 *     \b M, \b N, or \b K is zero, or a leading dimension is invalid,
 *     or the \b numCommandQueues parameter is not equal to 1
 *   - \b clAmdBlasInvalidMemObject if A, B, or C object is invalid,
 *     or an image object rather than the buffer one;
 *   - \b clAmdBlasOutOfHostMemory if the library can't allocate memory for
 *     internal structures
 *   - \b clAmdBlasInvalidCommandQueue if the passed command queue is invalid
 *   - \b clAmdBlasInvalidContext if a context a passed command queue belongs to
 *     was released
 *   - \b clAmdBlasInvalidOperation if kernel compilation relating to a previous
 *     call has not completed for any of the target devices
 *   - \b clAmdBlasCompilerNotAvailable if a compiler is not available
 *   - \b clAmdBlasBuildProgramFailure if there is a failure to build a program
 *     executable
 * @ingroup TRMM
 */
clAmdBlasStatus
clAmdBlasStrmm(
    clAmdBlasOrder order,
    clAmdBlasSide side,
    clAmdBlasUplo uplo,
    clAmdBlasTranspose transA,
    clAmdBlasDiag diag,
    size_t M,
    size_t N,
    cl_float alpha,
    const cl_mem A,
    size_t lda,
    cl_mem B,
    size_t ldb,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/**
 * @example example_strmm.c
 * This is an example of how to use the @ref clAmdBlasStrmm function.
 */

/**
 * @brief Multiplying a matrix by a triangular matrix with double elements.
 *
 * Matrix-triangular matrix products:
 *   - \f$ B \leftarrow \alpha T B \f$
 *   - \f$ B \leftarrow \alpha T^T B \f$
 *   - \f$ B \leftarrow \alpha B T \f$
 *   - \f$ B \leftarrow \alpha B T^T \f$
 *
 * where \b T is an upper or lower triangular matrix.
 *
 * @param[in] order
 * @param[in] side      The side of triangular matrix.
 * @param[in] uplo      The triangle in matrix being referenced.
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] diag      Specify whether matrix is unit triangular.
 * @param[in] M         Number of rows in matrices \b A and \b B.
 * @param[in] N         Number of columns in matrices \b A and \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object strogin matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. For detailed
 *                      description see clAmdBlasStrmm().
 * @param[out] B        Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. For detailed
 *                      description see clAmdBlasStrmm().
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return \b clAmdBlasSuccess on success; \b clAmdBlasInvalidDevice if
 *         a target device does not support floating point arithmetic with
 *         double precision; the same error codes as the clAmdBlasStrmm()
 *         function otherwise.
 * @ingroup TRMM
 */
clAmdBlasStatus
clAmdBlasDtrmm(
    clAmdBlasOrder order,
    clAmdBlasSide side,
    clAmdBlasUplo uplo,
    clAmdBlasTranspose transA,
    clAmdBlasDiag diag,
    size_t M,
    size_t N,
    cl_double alpha,
    const cl_mem A,
    size_t lda,
    cl_mem B,
    size_t ldb,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/**
 * @brief Multiplying a matrix by a triangular matrix with float complex
 * elements.
 *
 * Matrix-triangular matrix products:
 *   - \f$ B \leftarrow \alpha T B \f$
 *   - \f$ B \leftarrow \alpha T^T B \f$
 *   - \f$ B \leftarrow \alpha B T \f$
 *   - \f$ B \leftarrow \alpha B T^T \f$
 *
 * where \b T is an upper or lower triangular matrix.
 *
 * @param[in] order
 * @param[in] side      The side of triangular matrix.
 * @param[in] uplo      The triangle in matrix being referenced.
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] diag      Specify whether matrix is unit triangular.
 * @param[in] M         Number of rows in matrices \b A and \b B.
 * @param[in] N         Number of columns in matrices \b A and \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. For detailed
 *                      description see clAmdBlasStrmm().
 * @param[out] B        Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. For detailed
 *                      description see clAmdBlasStrmm().
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return The same result as the clAmdBlasStrmm() function.
 * @ingroup TRMM
 */
clAmdBlasStatus
clAmdBlasCtrmm(
    clAmdBlasOrder order,
    clAmdBlasSide side,
    clAmdBlasUplo uplo,
    clAmdBlasTranspose transA,
    clAmdBlasDiag diag,
    size_t M,
    size_t N,
    FloatComplex alpha,
    const cl_mem A,
    size_t lda,
    cl_mem B,
    size_t ldb,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/**
 * @brief Multiplying a matrix by a triangular matrix with double complex
 * elements.
 *
 * Matrix-triangular matrix products:
 *   - \f$ B \leftarrow \alpha T B \f$
 *   - \f$ B \leftarrow \alpha T^T B \f$
 *   - \f$ B \leftarrow \alpha B T \f$
 *   - \f$ B \leftarrow \alpha B T^T \f$
 *
 * where \b T is an upper or lower triangular matrix.
 *
 * @param[in] order
 * @param[in] side      The side of triangular matrix.
 * @param[in] uplo      The triangle in matrix being referenced.
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] diag      Specify whether matrix is unit triangular.
 * @param[in] M         Number of rows in matrices \b A and \b B.
 * @param[in] N         Number of columns in matrices \b A and \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. For detailed
 *                      description see clAmdBlasStrmm().
 * @param[out] B        Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. For detailed
 *                      description see clAmdBlasStrmm().
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return The same result as the clAmdBlasDtrmm() function.
 * @ingroup TRMM
 */
clAmdBlasStatus
clAmdBlasZtrmm(
    clAmdBlasOrder order,
    clAmdBlasSide side,
    clAmdBlasUplo uplo,
    clAmdBlasTranspose transA,
    clAmdBlasDiag diag,
    size_t M,
    size_t N,
    DoubleComplex alpha,
    const cl_mem A,
    size_t lda,
    cl_mem B,
    size_t ldb,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/*@}*/

/**
 * @defgroup TRSM xTRSM - Solving triangular systems of equations
 */
/*@{*/

/**
 * @brief Solving triangular systems of equations with multiple right-hand
 * sides and float elements.
 *
 * Solving triangular systems of equations:
 *   - \f$ B \leftarrow \alpha T^{-1} B \f$
 *   - \f$ B \leftarrow \alpha T^{-T} B \f$
 *   - \f$ B \leftarrow \alpha B T^{-1} \f$
 *   - \f$ B \leftarrow \alpha B T^{-T} \f$
 *
 * where \b T is an upper or lower triangular matrix.
 *
 * @param[in] order
 * @param[in] side      The side of triangular matrix.
 * @param[in] uplo      The triangle in matrix being referenced.
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] diag      Specify whether matrix is unit triangular.
 * @param[in] M         Number of rows in matrices \b A and \b B.
 * @param[in] N         Number of columns in matrices \b A and \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. It should be not less
 *                      than \b N when the \b side parameter is set to
 *                      \b clAmdBlasRowLeft,\n or not less than \b M
 *                      when it is set to \b clAmdBlasRight.
 * @param[out] B        Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. It should be not
 *                      less than \b N when the \b order parameter is set to
 *                      \b clAmdBlasRowMajor,\n or not less than \b M
 *                      when it is set to \b clAmdBlasColumnMajor.
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return \b clAmdBlasSuccess on success; following error codes otherwise:
 *   - \b clAmdBlasInvalidValue if invalid parameters are passed:
 *     \b M, \b N or \b K is zero, or a leading dimension is invalid,
 *     or the \b numCommandQueues parameter is not equal to 1
 *   - \b clAmdBlasInvalidMemObject if A, B, or C object is invalid,
 *     or an image object rather than the buffer one;
 *   - \b clAmdBlasOutOfHostMemory if the library can't allocate memory for
 *     internal structures
 *   - \b clAmdBlasInvalidCommandQueue if the passed command queue is invalid
 *   - \b clAmdBlasInvalidContext if a context a passed command queue belongs
 *     to was released
 *   - \b clAmdBlasInvalidOperation if kernel compilation relating to a previous
 *     call has not completed for any of the target devices
 *   - \b clAmdBlasCompilerNotAvailable if a compiler is not available
 *   - \b clAmdBlasBuildProgramFailure if there is a failure to build a program
 *     executable
 * @ingroup TRSM
 */
clAmdBlasStatus
clAmdBlasStrsm(
    clAmdBlasOrder order,
    clAmdBlasSide side,
    clAmdBlasUplo uplo,
    clAmdBlasTranspose transA,
    clAmdBlasDiag diag,
    size_t M,
    size_t N,
    cl_float alpha,
    const cl_mem A,
    size_t lda,
    cl_mem B,
    size_t ldb,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/**
 * @example example_strsm.c
 * This is an example of how to use the @ref clAmdBlasStrsm function.
 */

/**
 * @brief Solving triangular systems of equations with multiple right-hand
 * sides and double elements.
 *
 * Solving triangular systems of equations:
 *   - \f$ B \leftarrow \alpha T^{-1} B \f$
 *   - \f$ B \leftarrow \alpha T^{-T} B \f$
 *   - \f$ B \leftarrow \alpha B T^{-1} \f$
 *   - \f$ B \leftarrow \alpha B T^{-T} \f$
 *
 * where \b T is an upper or lower triangular matrix.
 *
 * @param[in] order
 * @param[in] side      The side of triangular matrix.
 * @param[in] uplo      The triangle in matrix being referenced.
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] diag      Specify whether matrix is unit triangular.
 * @param[in] M         Number of rows in matrices \b A and \b B.
 * @param[in] N         Number of columns in matrices \b A and \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. For detailed
 *                      description see clAmdBlasStrsm().
 * @param[out] B        Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. For detailed
 *                      description see clAmdBlasStrsm().
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return \b clAmdBlasSuccess on success; \b clAmdBlasInvalidDevice if
 *         a target device does not support floating point arithmetic with
 *         double precision; the same error codes as the clAmdBlasStrmm()
 *         function otherwise.
 * @ingroup TRSM
 */
clAmdBlasStatus
clAmdBlasDtrsm(
    clAmdBlasOrder order,
    clAmdBlasSide side,
    clAmdBlasUplo uplo,
    clAmdBlasTranspose transA,
    clAmdBlasDiag diag,
    size_t M,
    size_t N,
    cl_double alpha,
    const cl_mem A,
    size_t lda,
    cl_mem B,
    size_t ldb,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/**
 * @brief Solving triangular systems of equations with multiple right-hand
 * sides and float complex elements.
 *
 * Solving triangular systems of equations:
 *   - \f$ B \leftarrow \alpha T^{-1} B \f$
 *   - \f$ B \leftarrow \alpha T^{-T} B \f$
 *   - \f$ B \leftarrow \alpha B T^{-1} \f$
 *   - \f$ B \leftarrow \alpha B T^{-T} \f$
 *
 * where \b T is an upper or lower triangular matrix.
 *
 * @param[in] order
 * @param[in] side      The side of triangular matrix.
 * @param[in] uplo      The triangle in matrix being referenced.
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] diag      Specify whether matrix is unit triangular.
 * @param[in] M         Number of rows in matrices \b A and \b B.
 * @param[in] N         Number of columns in matrices \b A and \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. For detailed
 *                      description see clAmdBlasStrsm().
 * @param[out] B        Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. For detailed
 *                      description see clAmdBlasStrsm().
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return The same result as the clAmdBlasStrsm() function.
 * @ingroup TRSM
 */
clAmdBlasStatus
clAmdBlasCtrsm(
    clAmdBlasOrder order,
    clAmdBlasSide side,
    clAmdBlasUplo uplo,
    clAmdBlasTranspose transA,
    clAmdBlasDiag diag,
    size_t M,
    size_t N,
    FloatComplex alpha,
    const cl_mem A,
    size_t lda,
    cl_mem B,
    size_t ldb,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/**
 * @brief Solving triangular systems of equations with multiple right-hand
 * sides and double complex elements.
 *
 * Solving triangular systems of equations:
 *   - \f$ B \leftarrow \alpha T^{-1} B \f$
 *   - \f$ B \leftarrow \alpha T^{-T} B \f$
 *   - \f$ B \leftarrow \alpha B T^{-1} \f$
 *   - \f$ B \leftarrow \alpha B T^{-T} \f$
 *
 * where \b T is an upper or lower triangular matrix.
 *
 * @param[in] order
 * @param[in] side      The side of triangular matrix.
 * @param[in] uplo      The triangle in matrix being referenced.
 * @param[in] transA    How matrix \b A should be transposed.
 * @param[in] diag      Specify whether matrix is unit triangular.
 * @param[in] M         Number of rows in matrices \b A and \b B.
 * @param[in] N         Number of columns in matrices \b A and \b B.
 * @param[in] alpha     The factor of matrix \b A.
 * @param[in] A         Buffer object storing matrix \b A.
 * @param[in] lda       Leading dimension of matrix \b A. For detailed
 *                      description see clAmdBlasStrsm().
 * @param[out] B        Buffer object storing matrix \b B.
 * @param[in] ldb       Leading dimension of matrix \b B. For detailed
 *                      description see clAmdBlasStrsm().
 * @param[in] numCommandQueues          Number of OpenCL command queues where
 *                                      task should be performed. Currently
 *                                      only 1 command queue is supported.
 * @param[in] commandQueues             OpenCL command queues.
 * @param[in] numEventsInWaitList       Number of events in event wait list.
 * @param[in] eventWaitList             Event wait list.
 * @param[in] events     Event objects per each command queue that identify
 *                       particular kernel execution instance.
 *
 * @return The same result as the clAmdBlasDtrsm() function.
 * @ingroup TRSM
 */
clAmdBlasStatus
clAmdBlasZtrsm(
    clAmdBlasOrder order,
    clAmdBlasSide side,
    clAmdBlasUplo uplo,
    clAmdBlasTranspose transA,
    clAmdBlasDiag diag,
    size_t M,
    size_t N,
    DoubleComplex alpha,
    const cl_mem A,
    size_t lda,
    cl_mem B,
    size_t ldb,
    cl_uint numCommandQueues,
    cl_command_queue *commandQueues,
    cl_uint numEventsInWaitList,
    const cl_event *eventWaitList,
    cl_event *events);

/*@}*/

#ifdef __cplusplus
}      /* extern "C" { */
#endif

#endif /* CLAMDBLAS_H_ */
