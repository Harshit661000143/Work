#ifndef CLBLAS_H
#define CLBLAS_H

void dump_error(cl_int);
int main(int a,char **) 

#endif
